# VG Public Review Publish Pack



Pack: **publish_pack_20260303_115028**

Generated: **2026-03-03T12:18:59**



Repository: https://github.com/Bert-JanP/Incident-Response-Powershell.git

Commit: ****

Branch: ****




Author: https://github.com/vgplatformproject


## Contents



- ISSUE.md — ready-to-post issue text

- PR_SKELETON.md — optional PR plan (additive only)

- Tools/Repro/

  - New-RunManifest.ps1 — write per-run manifest.json (host+tool+inputs+repo meta)

  - Compare-RunFolders.ps1 — folder diff (path+sha256)

- artifacts/

  - review_notes.md

  - audit_result.json

  - baseline_compare_report.md

  - baseline_compare_report.json



