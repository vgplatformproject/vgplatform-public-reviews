PR Proposal (non-invasive, additive only)

Add:
Tools/Repro/
  - README_Repro.md
  - New-RunManifest.ps1
  - Compare-RunFolders.ps1

No changes to existing scripts.

Goal:
Opt-in reproducibility layer: manifest + baseline compare.
