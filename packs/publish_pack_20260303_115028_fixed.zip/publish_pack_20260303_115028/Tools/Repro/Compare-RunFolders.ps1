#requires -Version 7.0
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

param(
  [Parameter(Mandatory=$true)][string]$A,
  [Parameter(Mandatory=$true)][string]$B,
  [Parameter(Mandatory=$true)][string]$OutDir
)

function Fail([string]$m){ throw $m }
function Ok([string]$m){ Write-Host "[OK]   $m" -ForegroundColor Green }

if(-not (Test-Path $A)){ Fail "FOLDER_NOT_FOUND_A=$A" }
if(-not (Test-Path $B)){ Fail "FOLDER_NOT_FOUND_B=$B" }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Snapshot([string]$root){
  $files = Get-ChildItem -LiteralPath $root -Recurse -File -Force | Sort-Object FullName
  [hashtable]$h = @{}
  foreach($f in $files){
    $rel = $f.FullName.Substring($root.Length).TrimStart('\','/')
    $sha = (Get-FileHash -Algorithm SHA256 -LiteralPath $f.FullName).Hash.ToLowerInvariant()
    $h[$rel] = [pscustomobject]@{ path=$rel; size=[int64]$f.Length; sha256=$sha }
  }
  return $h
}

$SA = Snapshot $A
$SB = Snapshot $B

$added   = New-Object System.Collections.Generic.List[object]
$removed = New-Object System.Collections.Generic.List[object]
$changed = New-Object System.Collections.Generic.List[object]

foreach($k in @($SB.Keys)){ if(-not $SA.ContainsKey($k)){ $added.Add($SB[$k]) | Out-Null } }
foreach($k in @($SA.Keys)){ if(-not $SB.ContainsKey($k)){ $removed.Add($SA[$k]) | Out-Null } }
foreach($k in @($SA.Keys)){
  if($SB.ContainsKey($k)){
    $ra = $SA[$k]; $rb = $SB[$k]
    if($ra.sha256 -ne $rb.sha256 -or $ra.size -ne $rb.size){
      $changed.Add([pscustomobject]@{ path=$k; a_sha256=$ra.sha256; b_sha256=$rb.sha256; a_size=$ra.size; b_size=$rb.size }) | Out-Null
    }
  }
}

$report = [pscustomobject]@{
  schema    = "repro.folder_compare.v1"
  timestamp = (Get-Date).ToString("s")
  a = $A
  b = $B
  summary = [pscustomobject]@{ added=$added.Count; removed=$removed.Count; changed=$changed.Count }
  added   = $added
  removed = $removed
  changed = $changed
}

$jsonPath = Join-Path $OutDir "compare_report.json"
$mdPath   = Join-Path $OutDir "compare_report.md"
$enc = New-Object System.Text.UTF8Encoding($false)

[System.IO.File]::WriteAllText($jsonPath, ($report | ConvertTo-Json -Depth 10) + [Environment]::NewLine, $enc)

$md = New-Object System.Collections.Generic.List[string]
$md.Add("# Folder Compare Report")
$md.Add("")
$md.Add(("A: `{0}`" -f $A))
$md.Add(("B: `{0}`" -f $B))
$md.Add("")
$md.Add("## Summary")
$md.Add("")
$md.Add(("- Added: **{0}**" -f $report.summary.added))
$md.Add(("- Removed: **{0}**" -f $report.summary.removed))
$md.Add(("- Changed: **{0}**" -f $report.summary.changed))
$md.Add("")
$md.Add("> Companion JSON: compare_report.json")
[System.IO.File]::WriteAllLines($mdPath, $md, $enc)

Ok "WROTE=$jsonPath"
Ok "WROTE=$mdPath"