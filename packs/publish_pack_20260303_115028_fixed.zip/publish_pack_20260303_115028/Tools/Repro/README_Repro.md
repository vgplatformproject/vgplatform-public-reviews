# Repro Helpers (Optional)

This folder contains small, opt-in helper scripts:
- New-RunManifest.ps1: write a run manifest.json
- Compare-RunFolders.ps1: compare two output folders by path + sha256

These helpers are additive and do not modify existing DFIR/IR logic.
