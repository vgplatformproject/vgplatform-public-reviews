#requires -Version 7.0
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

param(
  [Parameter(Mandatory=$true)][string]$OutDir,
  [Parameter(Mandatory=$true)][string]$ToolName,
  [string]$RunId = "",
  [hashtable]$Inputs = @{},
  [string]$RepoPath = ""
)

function Ok([string]$m){ Write-Host "[OK]   $m" -ForegroundColor Green }

if(-not (Test-Path $OutDir)){
  New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
}

$meta = [pscustomobject]@{
  schema    = "repro.run_manifest.v1"
  timestamp = (Get-Date).ToString("s")
  tool      = $ToolName
  run_id    = $RunId
  inputs    = $Inputs
  host      = [pscustomobject]@{
    computer = $env:COMPUTERNAME
    user     = $env:USERNAME
    ps       = $PSVersionTable.PSVersion.ToString()
    os       = [System.Environment]::OSVersion.VersionString
  }
  repo      = [pscustomobject]@{ path=""; head=""; branch="" }
}

if($RepoPath -and (Test-Path $RepoPath) -and (Get-Command git -ErrorAction SilentlyContinue)){
  try {
    Push-Location $RepoPath
    $meta.repo.path   = $RepoPath
    $meta.repo.head   = (git rev-parse HEAD).Trim()
    $meta.repo.branch = (git rev-parse --abbrev-ref HEAD).Trim()
    Pop-Location
  } catch { try { Pop-Location } catch {} }
}

$out = Join-Path $OutDir "manifest.json"
$enc = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($out, ($meta | ConvertTo-Json -Depth 8) + [Environment]::NewLine, $enc)

Ok "WROTE=$out"
